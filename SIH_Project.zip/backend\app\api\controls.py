from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from app.database.session import get_sync_db
from app.database.models import SecurityControl
from app.api.auth import get_current_user

router = APIRouter(prefix="/controls", tags=["Security Control Engine"])

class CreateControlRequest(BaseModel):
    code: str
    name: str
    category: str = "IAM"
    description: Optional[str] = None
    coverage_percentage: float = 70.0
    effectiveness_percentage: float = 75.0
    maturity_level: int = 3
    implementation_cost: float = 1200000.0
    annual_cost: float = 300000.0
    modeled_risk_reduction: float = 4500000.0
    prerequisites: Optional[List[str]] = []

class UpdateControlRequest(BaseModel):
    coverage_percentage: Optional[float] = None
    effectiveness_percentage: Optional[float] = None
    implementation_cost: Optional[float] = None
    annual_cost: Optional[float] = None
    modeled_risk_reduction: Optional[float] = None

@router.post("")
def create_control(request: CreateControlRequest, current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    ctrl = SecurityControl(
        organization_id=current_user.organization_id,
        code=request.code,
        name=request.name,
        category=request.category,
        description=request.description,
        coverage_percentage=request.coverage_percentage,
        effectiveness_percentage=request.effectiveness_percentage,
        maturity_level=request.maturity_level,
        implementation_cost=request.implementation_cost,
        annual_cost=request.annual_cost,
        modeled_risk_reduction=request.modeled_risk_reduction,
        prerequisites=request.prerequisites or [],
        status="DEPLOYED" if request.coverage_percentage >= 80.0 else "PARTIALLY_DEPLOYED"
    )
    db.add(ctrl)
    db.commit()
    db.refresh(ctrl)
    return ctrl

@router.get("")
def list_controls(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    controls = db.query(SecurityControl).filter(SecurityControl.organization_id == current_user.organization_id).order_by(SecurityControl.modeled_risk_reduction.desc()).all()
    return controls

@router.get("/{control_id}")
def get_control(control_id: str, current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    ctrl = db.query(SecurityControl).filter(SecurityControl.id == control_id, SecurityControl.organization_id == current_user.organization_id).first()
    if not ctrl:
        raise HTTPException(status_code=404, detail="Control not found")
    return ctrl

@router.put("/{control_id}")
def update_control(control_id: str, request: UpdateControlRequest, current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    ctrl = db.query(SecurityControl).filter(SecurityControl.id == control_id, SecurityControl.organization_id == current_user.organization_id).first()
    if not ctrl:
        raise HTTPException(status_code=404, detail="Control not found")
        
    if request.coverage_percentage is not None:
        ctrl.coverage_percentage = request.coverage_percentage
    if request.effectiveness_percentage is not None:
        ctrl.effectiveness_percentage = request.effectiveness_percentage
    if request.implementation_cost is not None:
        ctrl.implementation_cost = request.implementation_cost
    if request.annual_cost is not None:
        ctrl.annual_cost = request.annual_cost
    if request.modeled_risk_reduction is not None:
        ctrl.modeled_risk_reduction = request.modeled_risk_reduction
        
    ctrl.status = "DEPLOYED" if ctrl.coverage_percentage >= 80.0 else "PARTIALLY_DEPLOYED"
    db.commit()
    db.refresh(ctrl)
    return ctrl
