from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
from typing import Dict, Any, List
from app.database.session import get_sync_db
from app.database.models import RiskAssessment, RiskHistory, Asset, Vulnerability, Organization, SecurityControl, RiskScenario
from app.api.auth import get_current_user
from app.risk_engine.calculator import calculate_risk_score, get_risk_level
from app.financial_engine.eal import calculate_eal
from app.blockchain.ledger import generate_canonical_hash

router = APIRouter(prefix="/risk", tags=["Continuous Cyber Risk Engine"])

@router.get("/overview")
@router.get("/enterprise")
def get_enterprise_risk(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    org = db.query(Organization).filter(Organization.id == current_user.organization_id).first()
    latest_assessment = db.query(RiskAssessment).filter(RiskAssessment.organization_id == current_user.organization_id).order_by(RiskAssessment.timestamp.desc()).first()
    
    score = latest_assessment.enterprise_risk_score if latest_assessment else 82.0
    eal = latest_assessment.expected_annual_loss if latest_assessment else 46000000.0
    appetite = org.risk_appetite_enterprise if org else 10000000.0
    
    appetite_status = "ABOVE RISK TOLERANCE" if eal > appetite else "WITHIN RISK APPETITE"
    
    contributors = latest_assessment.risk_contributors if (latest_assessment and latest_assessment.risk_contributors) else {
        "critical_vulnerability_pct": 25.0,
        "active_exploitation_pct": 20.0,
        "asset_criticality_pct": 20.0,
        "internet_exposure_pct": 15.0,
        "weak_control_segmentation_pct": 11.0,
        "other_environmental_factors_pct": 9.0
    }
    
    return {
        "enterprise_risk_score": score,
        "risk_level": get_risk_level(score),
        "expected_annual_loss": eal,
        "expected_annual_loss_label": f"₹{round(eal/10000000, 2)} Crore" if eal >= 10000000 else f"₹{round(eal/100000, 1)} Lakh",
        "modeled_loss_min": round(eal * 0.76, 2),
        "modeled_loss_max": round(eal * 1.35, 2),
        "confidence_percentage": 85.0,
        "risk_appetite_enterprise": appetite,
        "appetite_status": appetite_status,
        "risk_contributors": contributors,
        "modeled_label": "MODELED ESTIMATE",
        "timestamp": latest_assessment.timestamp.isoformat() if latest_assessment else datetime.utcnow().isoformat(),
        "last_assessment_date": latest_assessment.timestamp.isoformat() if latest_assessment else datetime.utcnow().isoformat(),
        "disclaimer": "All risk and loss outputs are modeled estimates based on quantitative probabilistic factors. Not guaranteed outcomes."
    }

@router.get("/assets")
def get_top_risky_assets(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    assets = db.query(Asset).filter(Asset.organization_id == current_user.organization_id).order_by(Asset.current_risk_score.desc()).limit(15).all()
    
    results = []
    for rank, a in enumerate(assets, start=1):
        vuln_count = db.query(Vulnerability).filter(Vulnerability.affected_asset_id == a.id).count()
        results.append({
            "rank": rank,
            "id": a.id,
            "name": a.name,
            "asset_type": a.asset_type,
            "ip_address": a.ip_address,
            "criticality_score": a.criticality_score,
            "current_risk_score": a.current_risk_score,
            "risk_level": get_risk_level(a.current_risk_score),
            "expected_annual_loss": a.expected_annual_loss,
            "expected_annual_loss_label": f"₹{round(a.expected_annual_loss/100000, 1)} Lakh" if a.expected_annual_loss < 10000000 else f"₹{round(a.expected_annual_loss/10000000, 2)} Cr",
            "internet_exposed": a.internet_exposed,
            "vulnerability_count": vuln_count,
            "recommended_action": "Apply Critical CVE Patch & Enable Zero-Trust Segmentation" if a.criticality_score > 90 else "Deploy EDR & Restrict Lateral Movement"
        })
    return results

@router.get("/history")
def get_risk_history(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    history = db.query(RiskHistory).filter(RiskHistory.organization_id == current_user.organization_id).order_by(RiskHistory.timestamp.asc()).all()
    return [
        {
            "timestamp": h.timestamp.isoformat(),
            "risk_score": h.risk_score,
            "expected_annual_loss": h.expected_annual_loss,
            "expected_annual_loss_label": f"₹{round(h.expected_annual_loss/10000000, 2)} Cr" if h.expected_annual_loss >= 10000000 else f"₹{round(h.expected_annual_loss/100000, 1)} L",
            "trigger_event": h.trigger_event
        }
        for h in history
    ]

@router.post("/recalculate")
@router.post("/calculate")
def recalculate_risk(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    # Recalculate each asset risk based on active vulns, technical exposure, and controls
    assets = db.query(Asset).filter(Asset.organization_id == current_user.organization_id).all()
    total_eal = 0.0
    weighted_risk = 0.0
    total_weights = 0.0

    for a in assets:
        active_vulns = db.query(Vulnerability).filter(
            Vulnerability.affected_asset_id == a.id,
            Vulnerability.remediation_status != "REMEDIATED"
        ).all()
        
        has_active_exploit = any(v.active_exploitation for v in active_vulns)
        max_cvss = max([v.cvss_score for v in active_vulns], default=6.5)
        
        in_attack_path = (a.criticality_score >= 90.0 or a.internet_exposed)
        control_eff = 45.0 if has_active_exploit else 80.0
        threat_level = 88.0 if has_active_exploit else 55.0

        calc = calculate_risk_score(
            threat_likelihood=threat_level,
            vulnerability_severity=max_cvss * 10.0,
            asset_criticality=a.criticality_score,
            control_effectiveness=control_eff,
            has_active_exploit=has_active_exploit,
            is_internet_exposed=a.internet_exposed,
            in_attack_path=in_attack_path
        )

        eal_calc = calculate_eal(
            threat_activity=threat_level,
            cvss_score=max_cvss,
            asset_criticality=a.criticality_score,
            has_active_exploit=has_active_exploit,
            is_internet_exposed=a.internet_exposed,
            control_effectiveness=control_eff,
            in_attack_path=in_attack_path
        )

        a.current_risk_score = calc["risk_score"]
        a.expected_annual_loss = eal_calc["expected_annual_loss"]
        total_eal += a.expected_annual_loss

        weight = (a.criticality_score / 10.0) ** 2.0
        weighted_risk += a.current_risk_score * weight
        total_weights += weight

    enterprise_score = round(weighted_risk / max(1.0, total_weights), 1) if assets else 75.0

    scenarios = db.query(RiskScenario).filter(RiskScenario.organization_id == current_user.organization_id).all()
    if scenarios:
        modeled_enterprise_eal = round(sum(s.expected_annual_loss for s in scenarios), 2)
    else:
        modeled_enterprise_eal = round(total_eal, 2)

    # Record new assessment snapshot
    now = datetime.utcnow()
    assessment = RiskAssessment(
        organization_id=current_user.organization_id,
        assessment_name="Dynamic Triggered Cyber Risk Recalculation",
        enterprise_risk_score=enterprise_score,
        risk_level=get_risk_level(enterprise_score),
        expected_annual_loss=round(modeled_enterprise_eal, 2),
        modeled_loss_min=round(modeled_enterprise_eal * 0.76, 2),
        modeled_loss_max=round(modeled_enterprise_eal * 1.35, 2),
        confidence_percentage=85.0,
        assessment_trigger="Manual / Event-Driven Recalculation Trigger",
        risk_contributors={
            "critical_vulnerability_pct": 25.0,
            "active_exploitation_pct": 20.0,
            "asset_criticality_pct": 20.0,
            "internet_exposure_pct": 15.0,
            "weak_control_segmentation_pct": 11.0,
            "other_environmental_factors_pct": 9.0
        },
        canonical_hash=generate_canonical_hash({"risk_score": enterprise_score, "eal": modeled_enterprise_eal, "timestamp": now.isoformat()}),
        timestamp=now
    )
    db.add(assessment)

    # Add to history
    rh = RiskHistory(
        organization_id=current_user.organization_id,
        timestamp=now,
        risk_score=enterprise_score,
        expected_annual_loss=round(modeled_enterprise_eal, 2),
        trigger_event="Continuous Recalculation Engine Executed"
    )
    db.add(rh)
    db.commit()

    return {
        "status": "SUCCESS",
        "enterprise_risk_score": enterprise_score,
        "expected_annual_loss": round(modeled_enterprise_eal, 2),
        "recalculated_assets_count": len(assets)
    }

@router.get("/{asset_id}")
def get_asset_risk_detail(asset_id: str, current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    asset = db.query(Asset).filter(Asset.id == asset_id, Asset.organization_id == current_user.organization_id).first()
    if not asset:
        raise HTTPException(status_code=404, detail="Asset not found")

    vulns = db.query(Vulnerability).filter(Vulnerability.affected_asset_id == asset_id).all()
    has_active_exploit = any(v.active_exploitation for v in vulns)
    max_cvss = max([v.cvss_score for v in vulns], default=6.5)

    eal_calc = calculate_eal(
        threat_activity=88.0 if has_active_exploit else 60.0,
        cvss_score=max_cvss,
        asset_criticality=asset.criticality_score,
        has_active_exploit=has_active_exploit,
        is_internet_exposed=asset.internet_exposed
    )

    return {
        "asset_id": asset.id,
        "asset_name": asset.name,
        "asset_type": asset.asset_type,
        "criticality_score": asset.criticality_score,
        "current_risk_score": asset.current_risk_score,
        "risk_level": get_risk_level(asset.current_risk_score),
        "expected_annual_loss": asset.expected_annual_loss,
        "modeled_eal_breakdown": eal_calc,
        "vulnerability_count": len(vulns),
        "has_active_exploit": has_active_exploit,
        "internet_exposed": asset.internet_exposed
    }


