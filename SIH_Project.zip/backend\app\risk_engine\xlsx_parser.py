"""
OpenXML Excel (.xlsx) Parser using Python Standard Library.
Zero third-party dependencies — parses .xlsx spreadsheets using zipfile and xml.etree.ElementTree.
"""

import zipfile
import xml.etree.ElementTree as ET
import csv
import io
from typing import List, Optional

def parse_xlsx_to_csv_text(xlsx_bytes: bytes) -> str:
    """
    Converts bytes of an .xlsx workbook into CSV-formatted text.
    Handles shared strings, inline strings, direct numbers, and formula outputs.
    """
    with zipfile.ZipFile(io.BytesIO(xlsx_bytes)) as zf:
        # 1. Parse shared strings lookup table
        shared_strings: List[str] = []
        ss_files = [n for n in zf.namelist() if n.lower().endswith("sharedstrings.xml")]
        if ss_files:
            ss_xml = zf.read(ss_files[0])
            tree = ET.fromstring(ss_xml)
            for elem in tree.iter():
                if elem.tag.endswith('si'):
                    # Accumulate all <t> tags within this <si>
                    parts = [t.text or "" for t in elem.iter() if t.tag.endswith('t')]
                    shared_strings.append("".join(parts))

        # 2. Identify the first worksheet XML
        sheet_candidates = [
            n for n in zf.namelist()
            if "worksheets/sheet" in n.lower() and n.lower().endswith(".xml")
        ]
        if not sheet_candidates:
            raise ValueError("No valid worksheets found in XLSX file archive.")
        
        sheet_path = sorted(sheet_candidates)[0]
        ws_xml = zf.read(sheet_path)
        ws_tree = ET.fromstring(ws_xml)

        # 3. Parse row elements
        rows: List[List[str]] = []
        for row_elem in ws_tree.iter():
            if row_elem.tag.endswith('row'):
                cell_values = []
                for cell in row_elem:
                    if cell.tag.endswith('c'):
                        cell_type = cell.attrib.get('t', '')
                        
                        # Find value tag <v> or inline string <is>
                        val_tag = None
                        for child in cell:
                            if child.tag.endswith('v') or child.tag.endswith('is'):
                                val_tag = child
                                break
                        
                        cell_text = ""
                        if val_tag is not None:
                            raw_val = val_tag.text or ""
                            if cell_type == 's':
                                # Lookup in shared strings
                                try:
                                    idx = int(raw_val)
                                    cell_text = shared_strings[idx] if idx < len(shared_strings) else raw_val
                                except (ValueError, IndexError):
                                    cell_text = raw_val
                            elif cell_type == 'b':
                                # Boolean: 1 = TRUE, 0 = FALSE
                                cell_text = "TRUE" if raw_val == "1" else "FALSE"
                            elif val_tag.tag.endswith('is'):
                                parts = [t.text or "" for t in val_tag.iter() if t.tag.endswith('t')]
                                cell_text = "".join(parts)
                            else:
                                cell_text = raw_val
                        cell_values.append(cell_text)
                if any(cell_values):
                    rows.append(cell_values)

        # 4. Serialize to standard CSV string
        out = io.StringIO()
        writer = csv.writer(out)
        for r in rows:
            writer.writerow(r)
        return out.getvalue()
