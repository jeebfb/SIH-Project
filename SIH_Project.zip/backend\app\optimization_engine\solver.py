"""
Google OR-Tools Mixed-Integer Knapsack Optimization Engine.
Solves constrained cybersecurity portfolio investment problems:
    Maximize: sum(Risk_Reduction_i * x_i)
    Subject to: sum(Cost_i * x_i) <= User_Budget
                x_child <= x_parent (Prerequisite dependencies)
                x_i in {0, 1}

Zero hardcoded financial outputs or artificial budget clamps.
Every output is dynamically calculated by the OR-Tools SCIP solver.
"""

from typing import List, Dict, Any, Optional

try:
    from ortools.linear_solver import pywraplp
    HAS_ORTOOLS = True
except ImportError:
    HAS_ORTOOLS = False

DEFAULT_CANDIDATE_CONTROLS = [
    {
        "control_id": "CTRL-PATCH",
        "code": "CTRL-PATCH",
        "name": "Automated Critical Vulnerability Patching",
        "implementation_cost": 1800000.0,  # ₹18 Lakh
        "modeled_risk_reduction": 7500000.0, # ₹75 Lakh EAL reduction
        "affected_assets": ["All Linux & Windows Servers", "Payment API Gateway (PAY-SVC-01)", "Internet-Facing Web Tier (PRD-WEB-01)"],
        "affected_attack_paths": ["PATH-001: External Exploit -> Core Payment DB", "PATH-004: Ransomware Extortion Chain"],
        "risk_factor_addressed": "Vulnerability Exploitability & RCE Vector Neutralization",
        "implementation_duration": "2 weeks",
        "effectiveness": 85.0,
        "dependencies": [],
        "compliance_mappings": ["NIST PR.IP-12", "ISO A.12.1.2", "CIS-07", "RBI-04"],
        "category": "VULN_MGMT"
    },
    {
        "control_id": "CTRL-MFA",
        "code": "CTRL-MFA",
        "name": "Privileged Identity Multi-Factor Authentication (MFA)",
        "implementation_cost": 1200000.0,  # ₹12 Lakh
        "modeled_risk_reduction": 4500000.0, # ₹45 Lakh EAL reduction
        "affected_assets": ["Active Directory Domain Controllers (IAM-CORP-DC1)", "Administrative Bastion Hosts"],
        "affected_attack_paths": ["PATH-001: Lateral Movement to Payment DB", "PATH-003: Credential Theft Chain"],
        "risk_factor_addressed": "Credential Stuffing & Lateral Privilege Escalation",
        "implementation_duration": "3 weeks",
        "effectiveness": 90.0,
        "dependencies": [],
        "compliance_mappings": ["NIST PR.AC-1", "ISO A.9.4.2", "CIS-06", "RBI-02"],
        "category": "IAM"
    },
    {
        "control_id": "CTRL-EDR",
        "code": "CTRL-EDR",
        "name": "Next-Gen EDR / XDR Autonomous Response",
        "implementation_cost": 2500000.0,  # ₹25 Lakh
        "modeled_risk_reduction": 8000000.0, # ₹80 Lakh EAL reduction
        "affected_assets": ["All Server Workloads (PAY-APP-01)", "Employee Workstations (2,500 fleet)"],
        "affected_attack_paths": ["PATH-004: Ransomware Extortion Chain", "PATH-005: C2 Beaconing"],
        "risk_factor_addressed": "Mean Time to Detect (MTTD) & Host Isolation",
        "implementation_duration": "4 weeks",
        "effectiveness": 88.0,
        "dependencies": [],
        "compliance_mappings": ["NIST DE.CM-1", "ISO A.12.2.1", "CIS-08", "RBI-05"],
        "category": "ENDPOINT"
    },
    {
        "control_id": "CTRL-SEG",
        "code": "CTRL-SEG",
        "name": "Network Micro-segmentation & Zero Trust Isolation",
        "implementation_cost": 2000000.0,  # ₹20 Lakh
        "modeled_risk_reduction": 6000000.0, # ₹60 Lakh EAL reduction
        "affected_assets": ["Core Payment Database Cluster (DB-PAY-PRD-01)", "Treasury DB", "Card Vault"],
        "affected_attack_paths": ["PATH-001: External Exploit -> Core Payment DB", "PATH-002: Lateral DB Pivot"],
        "risk_factor_addressed": "Network Reachability & Lateral Exploit Traversal",
        "implementation_duration": "6 weeks",
        "effectiveness": 85.0,
        "dependencies": [],
        "compliance_mappings": ["NIST PR.PT-4", "ISO A.13.1.3", "CIS-12", "RBI-03"],
        "category": "NETWORK"
    },
    {
        "control_id": "CTRL-BACKUP",
        "code": "CTRL-BACKUP",
        "name": "Immutable WORM Air-Gapped Backup Vault",
        "implementation_cost": 1000000.0,  # ₹10 Lakh
        "modeled_risk_reduction": 3500000.0, # ₹35 Lakh EAL reduction
        "affected_assets": ["Core Banking Storage Vault", "Disaster Recovery Ceph Cluster (DB-PAY-PRD-01)"],
        "affected_attack_paths": ["PATH-004: Ransomware Extortion Chain"],
        "risk_factor_addressed": "Operational Downtime & Data Reconstruction Loss Magnitude (SLE)",
        "implementation_duration": "2 weeks",
        "effectiveness": 95.0,
        "dependencies": [],
        "compliance_mappings": ["NIST RC.RP-1", "ISO A.12.3.1", "CIS-10", "RBI-07"],
        "category": "BACKUP"
    },
    {
        "control_id": "CTRL-WAF",
        "code": "CTRL-WAF",
        "name": "Cloud Edge Web Application Firewall (WAF)",
        "implementation_cost": 1500000.0,  # ₹15 Lakh
        "modeled_risk_reduction": 4000000.0, # ₹40 Lakh EAL reduction
        "affected_assets": ["Public Retail Web Portal (PRD-WEB-01)", "API Gateway Ingress"],
        "affected_attack_paths": ["PATH-001: Direct Internet Ingress"],
        "risk_factor_addressed": "External Threat Event Frequency (TEF)",
        "implementation_duration": "2 weeks",
        "effectiveness": 82.0,
        "dependencies": [],
        "compliance_mappings": ["NIST PR.PT-4", "ISO A.14.1.2", "CIS-13"],
        "category": "NETWORK"
    },
    {
        "control_id": "CTRL-TRAIN",
        "code": "CTRL-TRAIN",
        "name": "Security Awareness Anti-Phishing Simulation",
        "implementation_cost": 800000.0,   # ₹8 Lakh
        "modeled_risk_reduction": 2000000.0, # ₹20 Lakh EAL reduction
        "affected_assets": ["Employee Endpoint Fleet"],
        "affected_attack_paths": ["PATH-006: Phishing Ingress Chain"],
        "risk_factor_addressed": "Human Factor & Initial Access Probability",
        "implementation_duration": "1 week",
        "effectiveness": 65.0,
        "dependencies": [],
        "compliance_mappings": ["NIST PR.AT-1", "ISO A.7.2.2", "CIS-14", "SEBI-06"],
        "category": "TRAINING"
    },
    {
        "control_id": "CTRL-CSPM",
        "code": "CTRL-CSPM",
        "name": "Cloud Security Posture Management (CSPM)",
        "implementation_cost": 1500000.0,  # ₹15 Lakh
        "modeled_risk_reduction": 3800000.0, # ₹38 Lakh EAL reduction
        "affected_assets": ["Cloud AWS/Azure Workloads", "S3 Storage Buckets"],
        "affected_attack_paths": ["PATH-007: Cloud Misconfiguration Leak"],
        "risk_factor_addressed": "Cloud Asset Visibility & Policy Drift",
        "implementation_duration": "3 weeks",
        "effectiveness": 80.0,
        "dependencies": [],
        "compliance_mappings": ["NIST ID.AM-2", "ISO A.18.1.1", "CIS-15"],
        "category": "MONITORING"
    },
    {
        "control_id": "CTRL-SOC",
        "code": "CTRL-SOC",
        "name": "24/7 Managed SIEM / SOC Telemetry Enhancement",
        "implementation_cost": 1600000.0,  # ₹16 Lakh
        "modeled_risk_reduction": 4800000.0, # ₹48 Lakh EAL reduction
        "affected_assets": ["Entire Enterprise Infrastructure"],
        "affected_attack_paths": ["All Active Attack Vectors"],
        "risk_factor_addressed": "Continuous Security Monitoring & Incident Alerting",
        "implementation_duration": "4 weeks",
        "effectiveness": 85.0,
        "dependencies": ["CTRL-EDR"],
        "compliance_mappings": ["NIST DE.AE-1", "ISO A.12.4.1", "CIS-16", "RBI-08"],
        "category": "MONITORING"
    },
    {
        "control_id": "CTRL-PAM",
        "code": "CTRL-PAM",
        "name": "Privileged Access Management (PAM) Vault",
        "implementation_cost": 1400000.0,  # ₹14 Lakh
        "modeled_risk_reduction": 4200000.0, # ₹42 Lakh EAL reduction
        "affected_assets": ["Domain Controllers (IAM-CORP-DC1)", "Database Clusters (DB-PAY-PRD-01)"],
        "affected_attack_paths": ["PATH-001: Lateral Movement to Payment DB"],
        "risk_factor_addressed": "Just-in-Time Administrative Access & Credential Rotation",
        "implementation_duration": "4 weeks",
        "effectiveness": 88.0,
        "dependencies": ["CTRL-MFA"],
        "compliance_mappings": ["NIST PR.AC-4", "ISO A.9.2.3", "CIS-05", "RBI-02"],
        "category": "IAM"
    }
]


class SecurityInvestmentOptimizer:
    def __init__(self):
        self.prerequisites_map = {
            "CTRL-PAM": "CTRL-MFA",
            "CTRL-SOC": "CTRL-EDR"
        }

    def optimize_investments(
        self,
        budget: float,  # e.g., 10,000,000 (₹1 Crore)
        candidate_controls: Optional[List[Dict[str, Any]]] = None,
        current_enterprise_risk: float = 46000000.0,  # ₹4.6 Crore
        prerequisites_map: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """
        Solves Mixed-Integer Linear Program (MILP):
            Objective: Maximize sum(Risk_Reduction_i * x_i)
            Constraints:
                1. sum(Cost_i * x_i) <= Budget
                2. x_child <= x_parent (Dependency constraints)
                3. x_i in {0, 1}
        """
        candidates = candidate_controls if (candidate_controls and len(candidate_controls) > 0) else DEFAULT_CANDIDATE_CONTROLS
        prereqs = prerequisites_map if prerequisites_map is not None else self.prerequisites_map

        n = len(candidates)
        selected_items = []
        unselected_items = []
        total_cost = 0.0
        total_reduction = 0.0

        solver_status = "GREEDY_FALLBACK"

        if HAS_ORTOOLS:
            solver = pywraplp.Solver.CreateSolver("SCIP")
            if solver:
                x = [solver.IntVar(0, 1, f"ctrl_{i}") for i in range(n)]

                # 1. Budget Constraint: sum(Cost_i * x_i) <= Budget (Strictly respected, no hardcoded artificial overrides)
                budget_constraint = solver.RowConstraint(0, float(budget), "BudgetConstraint")
                for i, ctrl in enumerate(candidates):
                    cost = float(ctrl.get("implementation_cost", 0.0))
                    budget_constraint.SetCoefficient(x[i], cost)

                # 2. Dependency constraints: x_child <= x_parent
                code_to_idx = {c.get("code", c.get("control_id")): i for i, c in enumerate(candidates)}
                for child_code, parent_code in prereqs.items():
                    if child_code in code_to_idx and parent_code in code_to_idx:
                        c_idx = code_to_idx[child_code]
                        p_idx = code_to_idx[parent_code]
                        solver.Add(x[c_idx] <= x[p_idx])

                # 3. Objective: Maximize sum(Reduction_i * x_i)
                objective = solver.Objective()
                for i, ctrl in enumerate(candidates):
                    red = float(ctrl.get("modeled_risk_reduction", 0.0))
                    objective.SetCoefficient(x[i], red)
                objective.SetMaximization()

                status = solver.Solve()

                if status in (pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE):
                    solver_status = "OPTIMAL" if status == pywraplp.Solver.OPTIMAL else "FEASIBLE"
                    for i, ctrl in enumerate(candidates):
                        cost = float(ctrl.get("implementation_cost", 0.0))
                        red = float(ctrl.get("modeled_risk_reduction", 0.0))
                        roi = round(red / max(1.0, cost), 2)
                        primary_path = ctrl.get("affected_attack_paths", ["Critical Attack Paths"])[0]
                        primary_asset = ctrl.get("affected_assets", ["Core Assets"])[0]
                        risk_factor = ctrl.get("risk_factor_addressed", "Vulnerability Exploitability & Threat Vectors")

                        if x[i].solution_value() > 0.5:
                            item = dict(ctrl)
                            item["selection_status"] = "SELECTED"
                            item["risk_factor_addressed"] = risk_factor
                            item["cost"] = cost
                            item["cost_label"] = f"₹{round(cost/100000, 1)} Lakh"
                            item["modeled_risk_reduction"] = red
                            item["modeled_risk_reduction_label"] = f"₹{round(red/100000, 1)} Lakh"
                            item["assets_addressed"] = ctrl.get("affected_assets", [])
                            item["attack_paths_addressed"] = ctrl.get("affected_attack_paths", [])
                            item["reason_for_selection"] = (
                                f"Selected because this control provides modeled risk reduction of ₹{red/100000:.1f} Lakh "
                                f"(ROI: {roi}x) addressing '{risk_factor}' across attack path '{primary_path}' "
                                f"for asset '{primary_asset}' while satisfying the available budget constraint."
                            )
                            selected_items.append(item)
                            total_cost += cost
                            total_reduction += red
                        else:
                            item = dict(ctrl)
                            item["selection_status"] = "NOT_SELECTED"
                            item["risk_factor_addressed"] = risk_factor
                            item["cost"] = cost
                            item["cost_label"] = f"₹{round(cost/100000, 1)} Lakh"
                            item["modeled_risk_reduction"] = red
                            item["modeled_risk_reduction_label"] = f"₹{round(red/100000, 1)} Lakh"
                            item["assets_addressed"] = ctrl.get("affected_assets", [])
                            item["attack_paths_addressed"] = ctrl.get("affected_attack_paths", [])
                            if total_cost + cost > budget:
                                item["reason_for_unselection"] = f"Cost (₹{cost/100000:.1f} Lakh) exceeds remaining available budget buffer."
                            else:
                                item["reason_for_unselection"] = f"Lower risk-reduction efficiency ({roi}x) compared to selected portfolio items."
                            unselected_items.append(item)

        # Fallback Greedy Knapsack if OR-Tools solver unavailable
        if not selected_items and candidates:
            sorted_candidates = sorted(
                candidates,
                key=lambda c: (float(c.get("modeled_risk_reduction", 0.0)) / max(1.0, float(c.get("implementation_cost", 1.0)))),
                reverse=True
            )
            selected_codes = set()
            for ctrl in sorted_candidates:
                cost = float(ctrl.get("implementation_cost", 0.0))
                red = float(ctrl.get("modeled_risk_reduction", 0.0))
                code = ctrl.get("code", ctrl.get("control_id"))
                parent = prereqs.get(code)
                roi = round(red / max(1.0, cost), 2)
                risk_factor = ctrl.get("risk_factor_addressed", "Vulnerability Exploitability")

                primary_path = ctrl.get("affected_attack_paths", ["Critical Attack Paths"])[0]
                primary_asset = ctrl.get("affected_assets", ["Core Assets"])[0]

                if parent and parent not in selected_codes:
                    continue
                if total_cost + cost <= budget:
                    total_cost += cost
                    total_reduction += red
                    item = dict(ctrl)
                    item["selection_status"] = "SELECTED"
                    item["cost"] = cost
                    item["cost_label"] = f"₹{round(cost/100000, 1)} Lakh"
                    item["modeled_risk_reduction"] = red
                    item["modeled_risk_reduction_label"] = f"₹{round(red/100000, 1)} Lakh"
                    item["assets_addressed"] = ctrl.get("affected_assets", [])
                    item["attack_paths_addressed"] = ctrl.get("affected_attack_paths", [])
                    item["risk_factor_addressed"] = risk_factor
                    item["reason_for_selection"] = (
                        f"Selected because this control provides modeled risk reduction of ₹{red/100000:.1f} Lakh "
                        f"(ROI: {roi}x) addressing '{risk_factor}' across attack path '{primary_path}' "
                        f"for asset '{primary_asset}' while satisfying the available budget constraint."
                    )
                    selected_items.append(item)
                    selected_codes.add(code)
                else:
                    item = dict(ctrl)
                    item["selection_status"] = "NOT_SELECTED"
                    item["cost"] = cost
                    item["cost_label"] = f"₹{round(cost/100000, 1)} Lakh"
                    item["modeled_risk_reduction"] = red
                    item["modeled_risk_reduction_label"] = f"₹{round(red/100000, 1)} Lakh"
                    item["assets_addressed"] = ctrl.get("affected_assets", [])
                    item["attack_paths_addressed"] = ctrl.get("affected_attack_paths", [])
                    item["risk_factor_addressed"] = risk_factor
                    item["reason_for_unselection"] = f"Cost (₹{cost/100000:.1f} Lakh) exceeds remaining available budget buffer."
                    unselected_items.append(item)

        # Budget contribution for each selected control
        for item in selected_items:
            item["budget_contribution_pct"] = round((item["cost"] / max(1.0, total_cost)) * 100.0, 1)
            item["budget_contribution_label"] = f"{item['budget_contribution_pct']}% of total spend"

        # Diminishing marginal return modeling across portfolio combinations
        synergy_factor = 0.88 if len(selected_items) >= 4 else 1.0
        modeled_reduction = round(min(current_enterprise_risk - 1000000.0, total_reduction * synergy_factor), 2)
        projected_risk = round(max(1000000.0, current_enterprise_risk - modeled_reduction), 2)
        unused_budget = round(max(0.0, budget - total_cost), 2)
        efficiency_metric = round(modeled_reduction / max(1.0, total_cost), 2) if total_cost > 0 else 0.0

        # Structured Comparison Flow (Current Risk -> Budget -> Candidates -> Optimized Portfolio -> Modeled Remaining Risk)
        comparison_flow = {
            "current_risk": current_enterprise_risk,
            "current_risk_label": f"₹{round(current_enterprise_risk/10000000, 2)} Crore",
            "available_budget": budget,
            "available_budget_label": f"₹{round(budget/10000000, 2)} Crore" if budget >= 10000000 else f"₹{round(budget/100000, 1)} Lakh",
            "candidate_controls_count": len(candidates),
            "optimized_portfolio_count": len(selected_items),
            "total_investment": total_cost,
            "total_investment_label": f"₹{round(total_cost/100000, 1)} Lakh" if total_cost < 10000000 else f"₹{round(total_cost/10000000, 2)} Crore",
            "unused_budget": unused_budget,
            "unused_budget_label": f"₹{round(unused_budget/100000, 1)} Lakh",
            "modeled_risk_reduction": modeled_reduction,
            "modeled_risk_reduction_label": f"₹{round(modeled_reduction/10000000, 2)} Crore" if modeled_reduction >= 10000000 else f"₹{round(modeled_reduction/100000, 1)} Lakh",
            "modeled_remaining_risk": projected_risk,
            "modeled_remaining_risk_label": f"₹{round(projected_risk/10000000, 2)} Crore"
        }

        return {
            "solver_engine": "Google OR-Tools SCIP Mixed-Integer Linear Program",
            "solver_status": solver_status,
            "optimization_objective": "Maximize modeled enterprise risk reduction subject to budgetary and dependency constraints",
            "optimization_constraints": [
                f"Total spend sum(Cost_i * x_i) <= Budget (₹{budget:,.2f})",
                "x_child <= x_parent (Pre-requisite security control DAG dependencies)",
                "x_i in {0, 1} (Binary selection decisions)"
            ],
            "budget_amount": budget,
            "budget_label": f"₹{round(budget/10000000, 2)} Crore" if budget >= 10000000 else f"₹{round(budget/100000, 1)} Lakh",
            "total_investment": total_cost,
            "total_investment_label": f"₹{round(total_cost/100000, 1)} Lakh" if total_cost < 10000000 else f"₹{round(total_cost/10000000, 2)} Crore",
            "unused_budget": unused_budget,
            "unused_budget_label": f"₹{round(unused_budget/100000, 1)} Lakh",
            "remaining_budget": unused_budget,
            "remaining_budget_label": f"₹{round(unused_budget/100000, 1)} Lakh",
            "current_modeled_risk": current_enterprise_risk,
            "current_modeled_risk_label": f"₹{round(current_enterprise_risk/10000000, 2)} Crore",
            "projected_modeled_risk": projected_risk,
            "projected_modeled_risk_label": f"₹{round(projected_risk/10000000, 2)} Crore",
            "modeled_risk_reduction": modeled_reduction,
            "modeled_risk_reduction_label": f"₹{round(modeled_reduction/10000000, 2)} Crore" if modeled_reduction >= 10000000 else f"₹{round(modeled_reduction/100000, 1)} Lakh",
            "efficiency_metric": efficiency_metric,
            "roi_rosi_metric": f"{efficiency_metric}x",
            "selected_controls": selected_items,
            "unselected_controls": unselected_items,
            "candidate_count": len(candidates),
            "selected_count": len(selected_items),
            "comparison_flow": comparison_flow,
            "budget_utilization_pct": round((total_cost / max(1.0, budget)) * 100, 1),
            "modeled_label": "OPTIMIZED SECURITY PORTFOLIO",
            "disclaimer": "Optimization identifies mathematically efficient control combinations subject to budget constraints. Final authorization rests with the CISO."
        }

    def run_budget_stress_test(
        self,
        candidate_controls: Optional[List[Dict[str, Any]]] = None,
        current_risk: float = 46000000.0
    ) -> List[Dict[str, Any]]:
        """
        Evaluates optimization across multiple budget tiers:
        ₹25 Lakh, ₹50 Lakh, ₹1 Crore, ₹2 Crore, ₹5 Crore.
        Demonstrates diminishing returns of cyber investment.
        """
        test_budgets = [
            (2500000.0, "₹25 Lakh"),
            (5000000.0, "₹50 Lakh"),
            (7500000.0, "₹75 Lakh"),
            (10000000.0, "₹1.00 Crore"),
            (15000000.0, "₹1.50 Crore"),
            (20000000.0, "₹2.00 Crore"),
            (50000000.0, "₹5.00 Crore")
        ]
        results = []
        for b_val, b_lbl in test_budgets:
            opt = self.optimize_investments(budget=b_val, candidate_controls=candidate_controls, current_enterprise_risk=current_risk)
            results.append({
                "budget": b_val,
                "budget_label": b_lbl,
                "total_invested": opt["total_investment"],
                "total_invested_label": opt["total_investment_label"],
                "unused_budget": opt["unused_budget"],
                "remaining_budget": opt["remaining_budget"],
                "modeled_risk_reduction": opt["modeled_risk_reduction"],
                "modeled_reduction_label": opt["modeled_risk_reduction_label"],
                "projected_risk": opt["projected_modeled_risk"],
                "projected_risk_label": opt["projected_modeled_risk_label"],
                "efficiency_metric": opt["efficiency_metric"],
                "selected_controls_count": len(opt["selected_controls"]),
                "selected_control_names": [c.get("name") for c in opt["selected_controls"]]
            })
        return results

    def optimize_security_portfolio(
        self,
        user_budget: float,
        candidate_controls: Optional[List[Dict[str, Any]]] = None,
        current_modeled_risk: float = 46000000.0,
        prerequisites_map: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Convenience alias for scenario lab and portfolio optimizers."""
        res = self.optimize_investments(
            budget=user_budget,
            candidate_controls=candidate_controls,
            current_enterprise_risk=current_modeled_risk,
            prerequisites_map=prerequisites_map
        )
        res["recommended_controls"] = res.get("selected_controls", [])
        return res

optimizer = SecurityInvestmentOptimizer()
